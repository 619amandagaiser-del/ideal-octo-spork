const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('hub', {
  setPresence: (name, type) => ipcRenderer.invoke('presence:set', { name, state: type === 'game' ? 'Playing a game' : 'Using an app' }),
  clearPresence: () => ipcRenderer.invoke('presence:clear'),
  presenceStatus: () => ipcRenderer.invoke('presence:status'),
  openExternal: (url) => ipcRenderer.invoke('external:open', url)
});
