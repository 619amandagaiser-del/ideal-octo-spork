// All Discord code lives here so it can be swapped for the Social SDK later.
const fs = require('fs');
const path = require('path');
let RPC = null;
try { RPC = require('discord-rpc'); } catch (e) {}
let client = null, ready = false, pending = null, msg = 'Discord not connected';

function config() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8')); } catch (e) { return {}; }
}
function start() {
  const id = config().discordClientId;
  if (!RPC) { msg = 'Run npm install to enable Discord status'; return; }
  if (!id || String(id).startsWith('YOUR_')) { msg = 'Add your Client ID to config.json'; return; }
  client = new RPC.Client({ transport: 'ipc' });
  client.on('ready', () => { ready = true; msg = 'Connected to Discord'; if (pending) set(pending); });
  client.login({ clientId: id }).catch(() => { msg = 'Open the Discord app, then restart the hub'; });
}
function set(d) {
  pending = d;
  if (!ready) return;
  client.setActivity({ details: d.name, state: d.state || 'Playing from Gaming Hub', startTimestamp: Date.now(), instance: false }).catch(() => {});
}
function clear() { pending = null; if (ready) client.clearActivity().catch(() => {}); }
function status() { return { ready, msg }; }
function stop() { try { if (client) client.destroy(); } catch (e) {} }
module.exports = { start, set, clear, status, stop };
