# Gaming Hub

Gaming Hub brings your game and app shortcuts together in a Windows desktop launcher. While the app is open, it serves its own interface on a localhost address bound to this computer only.

## Highlights

- A featured shortcut, recently played row, library totals, and searchable collection
- Game, app, and saved filters
- Add and remove entries, mark favorites, and track sessions
- Gamepad navigation
- Discord Rich Presence and shareable invite messages
- A shortcut to The JJS pack Discord server
- A Browse shortcut opens web addresses in Windows' default browser

Web pages open in the default browser, so filtering depends on that browser and the network. Gaming Hub does not include embedded browser tabs or a web proxy. The localhost server serves only the hub interface and is not exposed to other devices on your network.

## Run

1. Install Node.js.
2. In this folder, run `npm install` and `npm install -D electron electron-builder`.
3. Optional: create an app at discord.com/developers/applications and add its Application ID to `config.json`.
4. Open the Discord app if you use Rich Presence, then run `npm start`.
5. The app window uses `http://127.0.0.1:4040/` by default. If that port is busy, it selects and remembers another local port. The active address is printed in the terminal.
6. To create a Windows installer, run `npm run dist`. The installer is placed in `dist/`.
