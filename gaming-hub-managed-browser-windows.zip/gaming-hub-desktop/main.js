const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const presence = require('./discord');
let win = null;
let localServer = null;
const web = (u) => /^https?:\/\//i.test(u);

function makeLocalServer() {
  const hubPath = path.join(__dirname, 'renderer', 'hub.html');
  const hubHtml = fs.readFileSync(hubPath);
  return http.createServer((req, res) => {
    let pathname = '';
    try { pathname = new URL(req.url, 'http://127.0.0.1').pathname; } catch (_e) {}
    if (req.method !== 'GET' || (pathname !== '/' && pathname !== '/hub.html')) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
    });
    res.end(hubHtml);
  });
}

function listen(server, port) {
  return new Promise((resolve, reject) => {
    const onError = (error) => reject(error);
    server.once('error', onError);
    server.listen(port, '127.0.0.1', () => {
      server.removeListener('error', onError);
      resolve(server.address().port);
    });
  });
}

async function startLocalServer() {
  let savedPort = 0;
  try {
    const portFile = path.join(app.getPath('userData'), 'localhost-port.json');
    savedPort = Number(JSON.parse(fs.readFileSync(portFile, 'utf8')).port) || 0;
  } catch (_e) {}
  const requestedPort = Number(process.env.GAMING_HUB_PORT || savedPort || 4040);
  if (!Number.isInteger(requestedPort) || requestedPort < 0 || requestedPort > 65535) {
    throw new Error('GAMING_HUB_PORT must be a valid port number.');
  }

  localServer = makeLocalServer();
  let port;
  try {
    port = await listen(localServer, requestedPort);
  } catch (error) {
    if (error.code !== 'EADDRINUSE' || requestedPort === 0) throw error;
    localServer = makeLocalServer();
    port = await listen(localServer, 0);
  }
  try {
    fs.writeFileSync(path.join(app.getPath('userData'), 'localhost-port.json'), JSON.stringify({ port }));
  } catch (_e) {}
  return `http://127.0.0.1:${port}/`;
}

function createWindow(hubUrl) {
  win = new BrowserWindow({
    width: 1200, height: 800, backgroundColor: '#0b0e14', title: 'Gaming Hub',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.setMenuBarVisibility(false);
  win.loadURL(hubUrl);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (web(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  const localOrigin = new URL(hubUrl).origin;
  win.webContents.on('will-navigate', (event, url) => {
    try { if (new URL(url).origin !== localOrigin) event.preventDefault(); }
    catch (_e) { event.preventDefault(); }
  });
}
app.whenReady().then(() => {
  presence.start();
  startLocalServer().then((hubUrl) => {
    console.log(`Gaming Hub is available locally at ${hubUrl}`);
    createWindow(hubUrl);
  }).catch((error) => {
    dialog.showErrorBox('Gaming Hub could not start', error.message || 'The local app server could not start.');
    app.quit();
  });
});
ipcMain.handle('presence:set', (e, d) => presence.set({ name: String((d && d.name) || '').slice(0, 100), state: String((d && d.state) || '').slice(0, 100) }));
ipcMain.handle('presence:clear', () => presence.clear());
ipcMain.handle('presence:status', () => presence.status());
ipcMain.handle('external:open', async (_e, value) => {
  try {
    const url = new URL(String(value));
    if (!['http:', 'https:'].includes(url.protocol)) return { ok: false };
    await shell.openExternal(url.href);
    return { ok: true };
  } catch (_error) {
    return { ok: false };
  }
});
app.on('window-all-closed', () => {
  presence.stop();
  if (localServer) localServer.close();
  app.quit();
});
